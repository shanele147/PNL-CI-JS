import { Component } from 'react';
import './App.css';
import UserCard from './components/UserCard';
/* import Header from './header';
import FooterClassComponent from "./footerClassComponent"; */
// import Count from './components/Count';
import CarColor from './components/CarColor';
import PhoneStore from './PhoneStore/PhoneStore';

const users = [
  {
    name: "Cristian Ro",
    title: "Football Player",
    hobbies: ["Football", "Swimming", "Travel"]
  },
  {
    name: "Shane Le",
    title: "Website Developer",
    hobbies: ["Book", "Photography", "Travel"]
  },
  {
    name: "Elon Musk",
    title: "CEO SpaceX",
    hobbies: ["Sport", "Coding", "Basket ball"]
  },
  {
    name: "John Lennon",
    title: "Singer",
    hobbies: ["Music", "Art", "Smoking"]
  },
]

class App extends Component {
  constructor(props) { 
    super(props);

    this.state = {
      isAuthenticated: false,
    };    
  }

  // This is not function, this is method in class OOP
  onLogIn = () => { 
    // wrong approach => React không cập nhật được state có thay đổi hay không khi gán trực tiếp
    this.state.isAuthenticated = true;

    // right
    this.setState({
      isAuthenticated: true,
    });
  }

  onLogOut = () => { 
    this.setState({
      isAuthenticated: false,
    });
  }

  render() {    
    const userCardsContent = users.map((user, index) => {
      return (
        <UserCard name={user.name} title={user.title} hobbies={user.hobbies} key={index} />
      );
    });

    /* if (this.state.isAuthenticated === true) {
      return (
        <div className="app">          
          {userCardsContent}
          <div className= "log-out">
            <button onClick={this.onLogOut}>Log out</button>
          </div>          
        </div>
      );
    } else { 
      return (
        <div className="warning">
          <h1>Hi, please log in first!</h1>
          <button onClick={this.onLogIn}>Log in</button>
        </div>
      )
    } */

    return (      
      // <Count /> 
      // <CarColor />
      <PhoneStore />
    )
  }  
}

export default App;
