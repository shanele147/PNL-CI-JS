import React, { Component } from "react";

class CarColor extends Component { 
    constructor(props) { 
        super(props);
        this.state = {
            color:"black-car.png",
        }        
    }

    onChangeColor = (newColor) => {      
        this.setState({
            color: newColor,
        });
    }
    render() { 
        return (
            <div class="car-container">
                <img src={`/images/${this.state.color}`}></img>
                <div>
                    <button onClick={() => this.onChangeColor("red-car.png")}>Red</button>
                    <button onClick={() => this.onChangeColor("black-car.png")}>Black</button>
                    <button onClick={() => this.onChangeColor("white-car.png")}>White</button>
                </div>                
            </div>
        )
    }
}

export default CarColor;