import { Component } from "react";

class UserCard extends Component {
    render() {
        // using detructuring
        const { name, title, hobbies } = this.props;
        return (
            <>
                <div className="card-container">
                    <div className="card-img"></div>
                    <h1 className="card-name">{name}</h1>
                    <div className="card-information">
                        <p><strong>Title: </strong>{title}</p>
                        <p><strong>Hobbies: </strong>{hobbies.join(", ")}</p>
                    </div>
                </div>
            </>
        );
    }
}

export default UserCard;