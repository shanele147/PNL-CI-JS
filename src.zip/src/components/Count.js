import React, { Component } from "react";

class Count extends Component {
    constructor(props) {
        super(props);
        // declare object state
        this.state = {
            count: 0,
        };
    }


    onIncrease = () => {
        const newCount = this.state.count + 1;
        this.setState({
            count: newCount,
        });
    }
    onDecrease = () => {
        const newCount = this.state.count - 1;
        this.setState({
            count: newCount,
        });
    }

    // develop : use varible for the same method
    onCountHandler = (value) => {
        const newCount = this.state.count + value;
        this.setState({
            count: newCount,
        });
    }

    render() {
        let myCount = this.state.count;
        return (
            <div>
                {/* use callback function to avoid loop infinite*/}
                <button onClick={() => this.onCountHandler(+1)}>Increase</button>
                <div>{myCount}</div>
                <button onClick={() => this.onCountHandler(-1)}>Decrease</button>
            </div>
        );
    }
}

export default Count;