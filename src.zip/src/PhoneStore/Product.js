import React, { Component } from 'react'

export default class Product extends Component {
  render() {
    const { name, img } = this.props.product;
    return (      
        <div className="phone-item">
          <div className="phone-image">
            <img src={img}></img>
          </div>
          <div className="phone-name">{name}</div>
          <button>Xem chi tiết</button>
        </div>
    )
  }
}
