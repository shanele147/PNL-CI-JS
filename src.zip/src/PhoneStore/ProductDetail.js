import React, { Component } from 'react';

export default class ProductDetail extends Component {
  render() {
    return (
      <div>ProductDetail</div>
    )
  }
}
