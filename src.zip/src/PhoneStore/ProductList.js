import React, { Component } from 'react'
import Product from './Product';

export default class ProductList extends Component {    
    render() {
        const phone = this.props.products.map((product, index) => { 
            return (
                <Product key={index} product={product} />
            )
        });
        

        return (
            <div className="phone-container">
                { phone}
            </div>
        );
  }
}
