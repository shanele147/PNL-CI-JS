// Arrow
/* const Header = () => {

} */

function Header() {
    // return JSX
    const name = "MindX";
    const a = 2;
    const b = 4;
    const isAuthenticated = false;
    // render with condition
    if (isAuthenticated) {
        return (
            <><h3>Result:</h3 >
                <ul>
                    <li>Plus: {a + b}</li>
                    <li>Multi: {a * b}</li>
                    <li>Minus: {b - a}</li>
                </ul>
            </>            
        );
    }

    else {
        return (
            <div>
                {/* <img alt='Logo' src="./public/logo192.png"></img> */}
                <h1>Hello <mark>{name}</mark> Technology</h1>
                <hr></hr>
            </div>
        )
    }

}
export default Header;