import React, { Component } from "react";

class FooterClassComponent extends Component {
    render() { 
        return (
            <div>
                <h1>Đây là footer nha</h1>
                <strike>Cấm sao chép dưới mọi hình thức</strike>
            </div>
        );
    }
}

export default FooterClassComponent;